<?php
require "../../includes/DbOperations.php";
$db = new DbOperations(); 
$ret=array();
	$firebase_token=$db->getToken($_POST['userID'])['token'];
	$firebase_token=$_POST["token"];

					if(isset($_POST['userID']) and
					isset($_POST['title']) and
					isset($_POST['message'])){
		
						require_once __DIR__ . '/notification.php';
						$notification = new Notification();
	
						$title = $_POST['title'];
						$message = isset($_POST['message'])?$_POST['message']:'';
						
						$notification->setTitle($title);
						$notification->setMessage($message);
						
                 $firebase_api = "AAAAc98AAxw:APA91bHX0_sWe3FCB2Tfd8U05140UgVidElNhbxJetCM2wdyuKIKH6Q8ct2cXGdBMWICAaGM75lHZQWgiIFVgOG6-PANIO948Kz5lb9DV2jW4-mQqNTJsH31JEMg1dLZT-_U-7rVT9jl";
                 $ret["api"]= $firebase_api;
                 $ret["token"]=$firebase_token;
						
						//$topic = $_POST['topic'];
						
						$requestData = $notification->getNotificatin();
						
						
		
	           	$fields = array(
								'to' => $firebase_token,
								'data' => $requestData,
							);
		
						// Set POST variables
						$url = 'https://fcm.googleapis.com/fcm/send';
 
						$headers = array(
							'Authorization: key=' . $firebase_api,
							'Content-Type: application/json'
						);
						
						// Open connection
						$ch = curl_init();
 
						// Set the url, number of POST vars, POST data
						curl_setopt($ch, CURLOPT_URL, $url);
 
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
						// Disabling SSL Certificate support temporarily
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 
						curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 
						// Execute post
						$result = curl_exec($ch);
						$ret['fields']=$fields;
						$ret["error"]=false;
						if($result === FALSE){
						    $ret["uns"]=1;
							die('Curl failed: ' . curl_error($ch));
						}else{
						    $ret["uns"]=2;
						}
						$ret["result"]=$result;
 
						// Close connection
						curl_close($ch);
						
						echo json_encode($ret,JSON_PRETTY_PRINT);
						
						
					}else{
					    
					    $ret["error"]=true;
					    $ret["message"]="required Field missing";
					    $ret["token"]=$firebase_token;
					    echo json_encode($rets,JSON_PRETTY_PRINT);
					}
					?>