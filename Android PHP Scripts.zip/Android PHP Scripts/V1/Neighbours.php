
<?php 

require "../includes/NeighboursOperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
		isset($_POST['latitude']) and 
			isset($_POST['longitude']) and 
				isset($_POST['altitude']) and
            isset($_POST["userID"]) and
            isset($_POST['time']))
           
		{
		//operate the data further 

		$db = new NeighboursOperations(); 
        
		$result = $db->retreiveNeighbours( $_POST['userID'],
                                    $_POST['latitude'],
									$_POST['longitude'],
									$_POST['altitude'],
									$_POST['time']
   								 );
   								 $response['error'] = false;
   								 $response['result']=$result;
        	
		
	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>