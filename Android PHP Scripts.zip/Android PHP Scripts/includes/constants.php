<?php 
	define('DB_NAME','id4810695_asn_asu_cse18');
	
define('DB_USER','id4810695_asnasucse18');
	
define('DB_PASSWORD','asn_asu_cse18');
	
define('DB_HOST','localhost');

	

?>