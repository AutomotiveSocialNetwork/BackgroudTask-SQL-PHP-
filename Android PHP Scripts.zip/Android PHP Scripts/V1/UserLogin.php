<?php 

require "../includes/DbOperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['email']) and isset($_POST['password']) ){
		$db = new DbOperations(); 
		$userID=0;

		if($db->userLogin( $_POST['email'] , $_POST['password'] )){
			$user = $db->getUserByEmail($_POST['email']);
			$response['error'] = false; 
			$response['ID'] = $user['ID'];
			
			

			$response['email'] = $user['email'];
			$response['password'] = $user['password'];
			
			$carResponse=$db->getCarId($user['ID']);
			
			    $response["carID"]=$carResponse["carID"];
			$response["carResponse"]=$carResponse;
			
		}else{
			$response['error'] = true; 
			$response['message'] = "Invalid username or password";			
		}

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}

echo json_encode($response);

?>