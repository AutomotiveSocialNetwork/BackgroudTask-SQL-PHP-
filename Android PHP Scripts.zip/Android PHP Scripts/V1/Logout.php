
<?php 

require "../includes/DbOperations.php";
require "../includes/CarOperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
		isset($_POST['userID']))
		{
		//operate the data further 

		$db = new DbOperations(); 
        
		$result = $db->setOffline( 	$_POST['userID']);
									
		
		
		if($result){
			$response['error'] = false; 
			$response['message'] = "User logout successfully";
            $response["userID"]=$_POST['userID'];
		}else{
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
            $response["userID"]=$_POST['userID'];
		}


	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>