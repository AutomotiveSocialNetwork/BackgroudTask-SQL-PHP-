<?php 

require "../includes/ProblemOperations.php";
require "../includes/NeighboursOperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
		
			isset($_POST['type']) and 
			isset($_POST['time']) and
            isset($_POST["location"]) and
            isset($_POST["carID"]) and
            isset($_POST["driverID"])and
            isset($_POST["message"])and
            isset($_POST["latitude"])and
            isset($_POST["longitude"])and 
            isset($_POST["altitude"]))
		{
		//operate the data further 

		$db = new ProblemOperations(); 
		$dbNeighbours=new NeighboursOperations();
        
		$resultJSON= $db->createProblem(   $_POST['type'],
								        $_POST['time'],
									    $_POST['location'],
									    $_POST["message"]);
        $resultRelationJSON=$db ->bindProblemDriverCar( $_POST["carID"],
                                                    $_POST["driverID"],
                                                    $resultJSON["problemID"]);
        
        $resultNeighbours=$dbNeighbours->retreiveNeighbours($_POST["driverID"],
                                                             $_POST["latitude"],
                                                             $_POST["longitude"],
                                                             $_POST["altitude"],
                                                              $_POST['time'],
                                                              $_POST['type'],
                                                              $_POST['message'],
                                                              true);
                                                              
                                                    
     
   								 
   	   
        
		
		if($resultJSON["return"] == -1){
			$response['error'] = true; 
			 
            
			$response['message'] = "Some error occurred please try again";
		}elseif($resultJSON["return"]==1){
			$response['error'] = false; 
            
			$response['message'] = "Problem set with ID = ".(string)$resultJSON["problemID"];			
		}			
		
		if($resultRelationJSON["return"]==1 ){
            $response['errorProblemDriverCar'] = false; 
            
			$response['messageProblemDriverCar'] = "ProblemDriverCar data inserted sucessfully";		
        }else{
            $response['errorProblemDriverCar'] = true; 
            
			$response['messageProblemDriverCar'] = "It seems ProblemDriverCar data has error";
        }
        $response["res"]=$resultRelationJSON;
        $response["neighboursResult"]=$resultNeighbours;
		
		
		
	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);

?>